<?php

session_start();
require '../asset/login-process.php';


if(isset($_POST['delete']))
{
    $uname = mysqli_real_escape_string($conn, $_POST['delete']);
    $id = mysqli_real_escape_string($conn, $_POST['delete']);

    $query = "DELETE FROM user_form WHERE id = $id";
    $query_run = mysqli_query($conn, $query);
    header("location:../view/acc-index.php");


    /*$query = "DELETE * FROM user_form, beneficiaries  INNER JOIN usersmessages  
    WHERE messages.messageid= usersmessages.messageid and messages.messageid = '1'"*/

}
?>