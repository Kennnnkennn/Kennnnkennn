<?php
	
	
	define('DB_SERVER','localhost');
	define('DB_USER','root');
	define('DB_PASS','');
	define('DB_NAME', 'sapdb');
	
	$con = mysqli_connect(DB_SERVER, DB_USER, DB_PASS, DB_NAME);
	
		
	$name = $_POST["name"];
	$gender = $_POST["gender"];
	$date = $_POST["dd"]."-".$_POST["mm"]."-".$_POST["yyyy"];
	$age = $_POST["age"];
	$address = $_POST["address"];
	$blood_group = $_POST["blood_group"];
	$religion = $_POST["religion"];
    $nationality = $_POST["nationality"];
    $username = $_POST["username"];
    $password = $_POST["password"];
	
	$query = "insert into register(name,gender,date,age,address,blood_group,nationality,username,password)
	values('$name','$gender','$birthdate','$age','$address','$blood_group','$religion','$nationality','$username','$password')";

	$result=mysqli_query($con,$query );

	if($result != NULL){
	?>
	<div id="regForm"><span class="success"></span><h1>Registration Success</h1></div>
	
	<?php
	}
	else{
        
	?>
	<div class="regForm"><h1>Oops!! Something went wrong.</h1></div>
	<?php
	}
	?>
