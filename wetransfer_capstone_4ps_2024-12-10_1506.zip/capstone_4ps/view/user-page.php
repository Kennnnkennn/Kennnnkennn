<?php
    session_start();
    require '../asset/login-process.php';
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Accounts</title>

    <link rel="stylesheet" href="../css/main.css">
    <link rel="stylesheet" href="../css/beneficiaries.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons"rel="stylesheet">
</head>
<body class="bgcolor">

    

    <div id = "header">
        <?php 
            include '../includes/user-header.php';
        ?>
    </div>    
    
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Profile
                            <a href="../view/user-add.php" class="btn btn-primary float-end d-flex"> 
                            <i class="material-icons me-2">person_add</i>Add Info
                            </a>
                        </h4>
                    </div>

                    <div class="card-body">
                        <table class="table table-bordered table-striped">
                                <?php    
                                    $query = "SELECT * FROM beneficiaries WHERE id = ".$_SESSION['auth_user'];
                                    $query_run = mysqli_query($conn, $query);

                                    if(mysqli_num_rows($query_run) > 0)
                                    {
                                        ?>
                                        <tr>
                                            <th>ID</th>
                                            <th>Name</th>
                                            <th>Gender</th>
                                            <th>Birth Date</th>
                                            <th>Age</th>
                                            <th>Address</th>
                                            <th>Ethnicity</th>
                                            <th>Marital Status</th>
                                            <th>Religion</th>
                                            <th>Employment</th>
                                            <th>Income</th>
                                        </tr>
                                        <tbody>
                                    <?php
                                        foreach($query_run as $user)
                                        {
                                    ?>

                                            <tr>
                                                <td><?= $user['id']; ?></td>
                                                <td><?= $user['name']; ?></td>
                                                <td><?= $user['gender']; ?></td>
                                                <td><?= $user['birth_date']; ?></td>
                                                <td><?= $user['age']; ?></td>
                                                <td><?= $user['address']; ?></td>
                                                <td><?= $user['ethnicity']; ?></td>
                                                <td><?= $user['marital_stat']; ?></td>
                                                <td><?= $user['religion']; ?></td>
                                                <td><?= $user['empl']; ?></td>
                                                <td><?= $user['income']; ?></td>
                                            </tr>

                                    <?php
                                        }
                                    ?>
                                    </tbody>
                                    <?php
                                    }
                                    else
                                    {   
                                    ?>
                                        <tbody>
                                            <?php echo "<h5>No Records Found</h5>"; ?>
                                        </tbody>
                                        
                                <?php
                                    }
                                ?>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        let idInput = document.querySelector('input[name="id"]');
        idInput.value = localStorage.getItem('aut_user');
    </script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
</body>
</html>