<?php

@include '../asset/login-process.php';

if(isset($_POST['submit'])){

   $title = mysqli_real_escape_string($conn, $_POST['title']);
   $pdate = $_POST['pdate'];
   $announce = $_POST['announce'];
   $poser = $_POST['poser'];

   $select = " SELECT * FROM announcement WHERE title = '$title' ";

   $result = mysqli_query($conn, $select);

   if(mysqli_num_rows($result) > 0){

      $error[] = 'Announcement already posted';

   }
   else {
         $insert = "INSERT INTO announcement(title,pdate,announce,poser) VALUES('$title','$pdate','$announce','$poser')";
         //$insert = "INSERT INTO user_form(uname,psword,user_type) VALUES ('".$uname."','".$psword."','".$user_type."')";
         mysqli_query($conn, $insert);
         header('location:../view/index.php');
      
   }

};
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Add Announcement</title>
    <link rel="stylesheet" href="../css/main.css">
    <link rel="stylesheet" href="../css/beneficiaries.css">
    
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons"rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
</head>
<body class="bgcolor">
    <div id = "header">
        <?php 
            include '../includes/header.php';
        ?>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Add Announcement
                            <a href="../view/index.php" class="btn btn-danger float-end d-flex me-2">
                                <i class="material-icons">first_page</i>BACK</a>
                        </h4>
                    </div>
                    <div class="card-body">
                        <form action="" method="POST">
                            <div class="date mb-3">
                                <label for="date">Date</label>
                                <input type="date" name="pdate" class="form-control">
                            </div>
                            <div class="ann-title mb-3">
                                <label for="Title">Title</label>
                                <input type="text" autocomplete="off" name="title" class="form-control">
                            </div>
                            <div class="mb-3">
                                <label for="Poser">By</label>
                                <input type="text" autocomplete="off" name="poser" class="form-control">
                            </div>
                            <div class="mb-3">
                                <label for="Announcement">Announcement</label>
                                <textarea name="announce" class="form-control ann-cont"></textarea>
                            </div>
                            <div class="mb-3">
                                <button type="submit" name="submit" class="btn btn-primary">Post</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
  </body>
</html>