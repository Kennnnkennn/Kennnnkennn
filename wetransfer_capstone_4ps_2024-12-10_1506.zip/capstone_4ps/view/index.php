<?php
    @include '../asset/login-process.php';
    session_start();

    /*if(!isset($_SESSION['admin_name']))
    {
        header('location:../view/loginpage.php');
    }*/
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>4Ps System</title>

    <link rel="stylesheet" href="../css/home.css">
    <link rel="stylesheet" href="../css/main.css">
    <link rel="stylesheet" href="../css/header.css">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons"rel="stylesheet">
</head>
<body class="bgcolor">
    <div id = "header">
        <?php 
            include '../includes/header.php';
        ?>
    </div>

    <div class = "card-wrapper">
        <div class = "card-container">
            <span class="num" data-val="400">
                <?php
                
                $sql="SELECT * FROM user_form WHERE user_type = 'user'";
                $result=mysqli_query($conn,$sql);
                if($rowcount = mysqli_num_rows($result))
                {
                // Return the number of rows in result set
                print_r($rowcount);
                // Free result set
                mysqli_free_result($result);

                }
                else{
                    echo "0";
                }
                ?>
            </span>
            <span class="text">Total Beneficiaries</span>
        </div>

        <div class = "card-container">
            <span class="num" data-val="400">
            <?php 
                $sql="SELECT * FROM beneficiaries WHERE gender='Male'";

                if ($result=mysqli_query($conn,$sql))
                {
                // Return the number of rows in result set
                $rowcount=mysqli_num_rows($result);
                printf($rowcount);
                // Free result set
                mysqli_free_result($result);

                } 
                 
            ?>
            </span>
            <span class="text">Total Male</span>
        </div>

        <div class = "card-container">
            <span class="num" data-val="400">
            <?php 
                $sql="SELECT * FROM beneficiaries WHERE gender='Female'";

                if ($result=mysqli_query($conn,$sql))
                {
                // Return the number of rows in result set
                $rowcount=mysqli_num_rows($result);
                printf($rowcount);
                // Free result set
                mysqli_free_result($result);

                } 
                 
            ?>
            </span>
            <span class="text">Total Female</span>
        </div>
    </div>

    <div class="container ad-con">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="d-flex align-items-center">
                            <h4 class="flex-grow-1">
                                Announcements
                            </h4>
                            <!-- <form class="d-flex search-con" role="search">
                                    <input class="form-control me-1" type="search" autocomplete="off" placeholder="Search" aria-label="Search">
                                    <button class="btn btn-outline-success me-2" type="submit">
                                        <i class="material-icons d-flex">search</i>
                                    </button>
                            </form> -->
                                
                            <a href="../view/ann-add.php" class="btn btn-primary float-end d-flex"> 
                                <i class="material-icons me-2">info</i>Add Announcement
                            </a>
                        </div>
                    </div>

                    <div class="card-body">
                        <table class="table table-bordered table-striped">
                            <tr>
                                <th>Title</th>
                                <th>Announcement</th>
                                <th>Date</th>
                                <th>By</th>
                                <th>Action</th>
                            </tr>
                            <tbody>
                                <?php
                                    $query = "SELECT * FROM announcement";
                                    $query_run = mysqli_query($conn, $query);

                                    if(mysqli_num_rows($query_run) > 0)
                                    {
                                        foreach($query_run as $apost)
                                        {
                                            ?>

                                            <tr>
                                                <td><?= $apost['title']; ?></td>
                                                <td><?= $apost['announce']; ?></td>
                                                <td><?= $apost['pdate']; ?></td>
                                                <td><?= $apost['poser']; ?></td>
                                                <td>
                                                    <a href="../view/ann-add.php?announcement=<?= $apost['title']; ?>" class="btn btn-success btn-sm">
                                                    <i class="material-icons me-1">edit</i>Edit
                                                    </a>

                                                    <form action="../asset/ann-delete.php" method="POST" class="d-inline">
                                                        <button type="submit" name="delete" value="<?=$apost['title'];?>" class="btn btn-danger btn-sm items-align-center">
                                                        <i class="material-icons me-1">delete</i>Delete</a></button>
                                                    </form>
                                                </td>
                                            </tr>

                                            <?php
                                        }
                                    }
                                    else
                                    {
                                        echo "<h5>No Records Found</h5>";
                                    }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>


<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js" 
integrity="sha384-zYPOMqeu1DAVkHiLqWBUTcbYfZ8osu1Nd6Z89ify25QV9guujx43ITvfi12/QExE" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.min.js" 
integrity="sha384-Y4oOpwW3duJdCWv5ly8SCFYWqFDsfob/3GkgExXKV4idmbt98QcxXYs9UoXAB7BZ" crossorigin="anonymous"></script>

</body>
</html>