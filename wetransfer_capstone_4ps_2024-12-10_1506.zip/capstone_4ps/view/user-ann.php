<?php
    @include '../asset/login-process.php';
    session_start();


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Announcement</title>

    <link rel="stylesheet" href="../css/main.css">
    <link rel="stylesheet" href="../css/home.css">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet"
    integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons"rel="stylesheet">
</head>
<body class="bgcolor">
    <div id = "header">
        <?php 
            include '../includes/user-header.php';
        ?>
    </div> 
    <div class="container ann-con">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="d-flex align-items-center">
                            <h4 class="flex-grow-1">
                                Announcements
                            </h4>
                            <form class="d-flex search-con" role="search">
                                    <input class="form-control me-1" type="search" autocomplete="off" placeholder="Search" aria-label="Search">
                                    <button class="btn btn-outline-success me-2" type="submit">
                                        <i class="material-icons d-flex">search</i>
                                    </button>
                            </form>
                        </div>
                    </div>

                    <div class="card-body">
                        <table class="table table-bordered table-striped">
                            <tr>
                                <th>Title</th>
                                <th>Announcement</th>
                                <th>Date</th>
                                <th>By</th>
                            </tr>
                            <tbody>
                                <?php
                                    $query = "SELECT * FROM announcement";
                                    $query_run = mysqli_query($conn, $query);

                                    if(mysqli_num_rows($query_run) > 0)
                                    {
                                        foreach($query_run as $apost)
                                        {
                                            ?>

                                            <tr>
                                                <td><?= $apost['title']; ?></td>
                                                <td><?= $apost['announce']; ?></td>
                                                <td><?= $apost['pdate']; ?></td>
                                                <td><?= $apost['poser']; ?></td>
                                                
                                            </tr>

                                            <?php
                                        }
                                    }
                                    else
                                    {
                                        echo "<h5>No Records Found</h5>";
                                    }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.7/dist/umd/popper.min.js" 
integrity="sha384-zYPOMqeu1DAVkHiLqWBUTcbYfZ8osu1Nd6Z89ify25QV9guujx43ITvfi12/QExE" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.min.js" 
integrity="sha384-Y4oOpwW3duJdCWv5ly8SCFYWqFDsfob/3GkgExXKV4idmbt98QcxXYs9UoXAB7BZ" crossorigin="anonymous"></script>
</body>
</html>