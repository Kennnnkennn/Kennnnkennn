<?php
    session_start();
    require '../asset/login-process.php';

    if(isset($_POST['update']))
    {
        $id = ($_POST['id']);
        $uname = mysqli_real_escape_string($conn, $_POST['uname']);
        $psword = ($_POST['psword']);
        $name = ($_POST['name']);
        $gender = ($_POST['gender']);
        $birth_date = ($_POST['birth_date']);
        $age = ($_POST['age']);
        $address = ($_POST['address']);
        $ethnicity = ($_POST['ethnicity']);
        $mar_stat = ($_POST['marital_stat']);
        $religion = ($_POST['religion']);
        $empl = ($_POST['empl']);
        $income = ($_POST['income']);

        $query = "UPDATE user_form SET uname = '$uname', psword = '$psword' WHERE id = $id";
        $query2 ="UPDATE beneficiaries SET name='$name', gender='$gender', birth_date='$birth_date', age=$age, 
        address='$address', ethnicity ='$ethnicity', marital_stat = '$mar_stat', 
        religion='$religion', empl='$empl', income=$income WHERE id = $id";
        $query_run = mysqli_query($conn, $query);
        $query_run2 = mysqli_query($conn, $query2);
        header('location:../view/acc-index.php');
    };
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Beneficiaries</title>
    <link rel="stylesheet" href="../css/main.css">
    <link rel="stylesheet" href="../css/beneficiaries.css">
    
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons"rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
</head>
<body class="bgcolor">
    <div id = "header">
        <?php 
            include '../includes/header.php';
        ?>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Edit Account
                            <a href="../view/acc-index.php" class="btn btn-danger float-end d-flex">
                                <i class="material-icons me-1">first_page</i>BACK
                            </a>
                        </h4>
                    </div>
                    <div class="card-body">
                        <?php
                        if(isset($_GET['id']))
                        {
                            
                            $id = mysqli_real_escape_string($conn, $_GET['id']);
                            $query = "SELECT * FROM user_form LEFT JOIN beneficiaries ON user_form.id = beneficiaries.id 
                            WHERE user_form.id = $id";
                            $query_run = mysqli_query($conn, $query);
                            //echo $query_run;
                            if(mysqli_num_rows($query_run) > 0)
                            {
                                $user = mysqli_fetch_array($query_run);
                                ?>
                                    <form action="" method="POST">
                                        <div class="unamepass mb-3">
                                            <!-- <label for="id">ID</label> -->
                                            <input type="text" name="id" readonly="true" class="form-control" value="<?= $id?>">

                                            <label for="username">Username</label>
                                            <input type="text" name="uname" value = <?= $user['uname']?> class="form-control upass" autocomplete="off">

                                            <label for="password">Password</label>
                                            <input type="password" name="psword" value = <?= $user['psword']?> class="form-control upass" autocomplete="off">
                                        </div>
                                        <div class="mb-3">
                                            PERSONAL INFORMATION:
                                        </div>
                                        <div class="unamepass mb-3">
                                            <label for="name">name</label>
                                            <input type="text" name="name" value = "<?= $user['name']?>" class="form-control upass" autocomplete="off">

                                            <label for="gender">Gender</label>
                                            <input type="text" name="gender" value = "<?= $user['gender']?>" class="form-control upass" autocomplete="off">
                                        </div>
                                        <div class="unamepass mb-2">
                                            <label for="bdate">Birthdate</label>
                                            <input type="date" name="birth_date" value = <?= $user['birth_date']?> class="form-control upass" autocomplete="off">

                                            <label for="age">age</label>
                                            <input type="text" name="age" value = "<?= $user['age']?>" class="form-control upass" autocomplete="off">
                                        </div>
                                        <div class="unamepass mb-3">
                                            <label for="addr">Address</label>
                                            <input type="text" name="address" value = "<?= $user['address']?>" class="form-control upass" autocomplete="off">

                                            <label for="ethnicity">Ethnicity</label>
                                            <input type="text" name="ethnicity" value = "<?= $user['ethnicity']?>" class="form-control upass" autocomplete="off">
                                        </div>
                                        <div class="unamepass mb-3">
                                            <label for="religion">Religion</label>
                                            <input type="text" name="religion" value = "<?= $user['religion']?>" class="form-control upass" autocomplete="off">
                                        </div>
                                        <div class="unamepass mb-3">
                                            <label for="employee">Employee</label>
                                            <input type="text" name="empl" value = "<?= $user['empl']?>" class="form-control upass" autocomplete="off">

                                            <label for="income">Income</label>
                                            <input type="text" name="income" value = "<?= $user['income']?>" class="form-control upass" autocomplete="off">
                                        </div>
                
                                        <div class="mb-3">
                                            <button type="submit" name="update" class="btn btn-primary">Update</button>
                                        </div>
                                    </form>
                                <?php
                            }
                            else {
                                echo "<h4> No User Found </h4>";
                            }
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
  </body>
</html>