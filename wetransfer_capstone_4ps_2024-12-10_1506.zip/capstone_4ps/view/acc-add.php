<?php

@include '../asset/login-process.php';

if(isset($_POST['submit'])){

   $uid = $_POST['id'];
   $uname = mysqli_real_escape_string($conn, $_POST['uname']);
   $psword = $_POST['psword'];
   $user_type = $_POST['user_type'];

   $select = " SELECT * FROM user_form WHERE uname = '$uname' && psword = '$psword' ";

   $result = mysqli_query($conn, $select);

   if(mysqli_num_rows($result) > 0){

      $error[] = 'user already exist!';

   }
   else {
         $insert = "INSERT INTO user_form(id,uname,psword,user_type) VALUES('$uid','$uname','$psword','$user_type')";
         //$insert = "INSERT INTO user_form(uname,psword,user_type) VALUES ('".$uname."','".$psword."','".$user_type."')";
         mysqli_query($conn, $insert);
         header('location:../view/acc-index.php');
      
   }

};
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Beneficiaries</title>
    <link rel="stylesheet" href="../css/main.css">
    <link rel="stylesheet" href="../css/beneficiaries.css">
    
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons"rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
</head>
<body class="bgcolor">
    <div id = "header">
        <?php 
            include '../includes/header.php';
        ?>
    </div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Add Account
                            <a href="../view/acc-index.php" class="btn btn-danger float-end d-flex">
                                <i class="material-icons me-2">first_page</i>BACK</a>
                        </h4>
                    </div>
                    <div class="card-body">
                        <form action="" method="POST">
                            <div class="mb-3">
                                <input type="hidden" name="id" class="form-control" 
                                value="<?= mysqli_insert_id($conn); 
                                //echo $user['id'] == null ? 0 : $user['id'] ?>">
                                <label for="username">Username</label>
                                <input type="text" autocomplete="off" name="uname" class="form-control">
                            </div>
                            <div class="mb-3">
                                <label for="password">Password</label>
                                <input type="password" autocomplete="off" name="psword" class="form-control">
                            </div>
                            <div class="mb-3">
                                <select name="user_type">
                                    <option value="user">User</option>
                                    <option value="admin">Admin</option>
                                </select>
                            </div>
                            <div class="mb-3">
                                <button type="submit" name="submit" class="btn btn-primary">Add</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
  </body>
</html>