<?php
    session_start();
    require '../asset/login-process.php';
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Accounts</title>

    <link rel="stylesheet" href="../css/main.css">
    <link rel="stylesheet" href="../css/beneficiaries.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-KK94CHFLLe+nY2dmCWGMq91rCGa5gtU4mk92HdvYe+M/SXH301p5ILy+dN9+nJOZ" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons"rel="stylesheet">
</head>
<body class="bgcolor">
    <div id = "header">
        <?php 
            include '../includes/header.php';
        ?>
    </div>    

    <div class="container acc-con">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="d-flex align-items-center">
                            <h4 class="flex-grow-1">
                                Beneficiary Accounts
                            </h4>
                            <form class="d-flex search-con" role="search">
                                    <input class="form-control me-2" type="search" name="search" placeholder="search" aria-label="search">
                                    <button class="btn btn-outline-success me-2" type="submit">
                                        <i class="material-icons d-flex">search</i>
                                    </button>
                            </form>
                                
                            <a href="../view/acc-add.php" class="btn btn-primary float-end d-flex align-items-center"> 
                                <i class="material-icons me-2">person_add</i>Add User
                            </a>
                        </div>
                    </div>

                    <div class="card-body">
                        <table class="table table-bordered table-striped">
                            
                            <tbody>
                                <?php
                                    if(isset($_GET['search'])){
                                        $search = $_GET['search'];
                                    }
                                    else{
                                        $search = "";
                                    }
                                    if (empty($search)) {
                                        $query = "SELECT * FROM user_form";
                                    }
                                    else {
                                        $query = "SELECT * FROM user_form LEFT JOIN beneficiaries ON user_form.id = beneficiaries.id WHERE user_form.id = '$search' OR user_form.uname LIKE '%$search%' OR name LIKE '%$search%'";
                                        // $query = "SELECT * FROM `user_form` LEFT JOIN 'beneficiaries' WHERE user_form.id = $value 
                                        // OR user_form.uname LIKE '%$value%' OR beneficiaries.name LIKE '%$name%'";
                                    }
                                    
                                    $query_run = mysqli_query($conn, $query);
                                    
                                    if($query_run && mysqli_num_rows($query_run) > 0)
                                    {
                                    ?>
                                        <tr>
                                            <th>ID</th>
                                            <th>Username</th>
                                            <th>Password</th>
                                            <th>User_Type</th>
                                            <th>Action</th>
                                        </tr>
                                        <?php
                                        foreach($query_run as $user)
                                        {
                                            ?>

                                            <tr>
                                                <td><?= $user['id']?></td>
                                                <td><?= $user['uname']; ?></td>
                                                <td><?= $user['psword']; ?></td>
                                                <td><?= $user['user_type']; ?></td>
                                                <td>
                                                    <a href="../view/acc-edit.php?id=<?= $user['id']; ?>" class="btn btn-success btn-sm">
                                                    <i class="material-icons">edit</i>Edit
                                                    </a>

                                                    <form action="../asset/acc-delete.php" method="POST" class="d-inline">
                                                        <button type="submit" name="delete" value="<?=$user['id'];?>" class="btn btn-danger btn-sm">
                                                        <i class="material-icons">delete</i>Delete</a></button>
                                                    </form>
                                                </td>
                                            </tr>

                                            <?php
                                        }
                                    }
                                    else
                                    {
                                        echo "<h5>No Records Found</h5>";
                                    }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ENjdO4Dr2bkBIFxQpeoTz1HIcje39Wm4jDKdf19U8gI4ddQ3GYNS7NTKfAdVQSZe" crossorigin="anonymous"></script>
</body>
</html>